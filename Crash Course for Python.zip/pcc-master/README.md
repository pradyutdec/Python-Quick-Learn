Python Crash Course
===

A Hands-On, Project-Based Introduction to Programming
---

This is a collection of resources for [Python Crash Course](http://www.nostarch.com/pythoncrashcourse/), an introductory programming book from [No Starch Press](http://www.nostarch.com) 

If you have any questions about Python Crash Course, feel free to get in touch:

Email: pradyutdxc@gmail.com

<a href="setup_instructions"></a>Setup Instructions
---



